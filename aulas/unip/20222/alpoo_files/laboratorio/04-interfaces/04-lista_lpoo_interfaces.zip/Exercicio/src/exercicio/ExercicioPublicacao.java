package exercicio;

import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JOptionPane;

public class ExercicioPublicacao {
    public static void main(String[] args) {
       
        ArrayList publicacaoes = new ArrayList();
         for (int i=0; i < 2; i++){
            PublicacaoImportada publicacao = new PublicacaoImportada();
            publicacao.setTitulo(JOptionPane.showInputDialog("Titulo"));
            publicacao.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Código")));
            publicacao.setNumeroPaginas(Integer.parseInt(JOptionPane.showInputDialog("Número de Páginas")));
            publicacao.setRegiaoOrigem(JOptionPane.showInputDialog("Região"));
            publicacao.calcularCusto();
            publicacao.calcularImposto();
            publicacaoes.add(publicacao);
         }
        
        PublicacaoImportada p;
        Iterator i = publicacaoes.iterator();
        while (i.hasNext()){
            p = (PublicacaoImportada) i.next();
            JOptionPane.showMessageDialog(null, p.getTitulo() + '\n' + p.getCodigo()
        + '\n' + p.getNumeroPaginas() + '\n' + p.getCusto()+ '\n' + p.getImposto());
        }
        
    }
    
}
