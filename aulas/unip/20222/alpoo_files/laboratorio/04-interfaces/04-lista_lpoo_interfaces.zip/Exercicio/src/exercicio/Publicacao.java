
package exercicio;


public class Publicacao implements Produto{
    
    protected String titulo;
    protected int codigo;
    protected int numeroPaginas;
    protected float custo;
    protected float imposto;
        
    public Publicacao(){
    
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public float getCusto() {
        return custo;
    }

    public void setCusto(float custo) {
        this.custo = custo;
    }

    public float getImposto() {
        return imposto;
    }

    public void setImposto(float imposto) {
        this.imposto = imposto;
    }
    
    @Override
    public void calcularCusto() {
        if( getNumeroPaginas() > 200) {
            this.setCusto(0.085F * this.getNumeroPaginas());
        }
        else{
            this.setCusto(0.2F * this.getNumeroPaginas());
        }
    }

    
    @Override
    public void calcularImposto() {
        this.setImposto(0.1F * this.getCusto());
    }

    
}