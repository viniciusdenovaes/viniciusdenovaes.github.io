package exercicio;


public interface Produto {
    public void calcularCusto();
    public void calcularImposto();
}
