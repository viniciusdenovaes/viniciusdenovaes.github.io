

package exercicio;


public class PublicacaoImportada extends Publicacao {
    private String regiaoOrigem;
    
    public PublicacaoImportada(){

    }
        
    @Override
    public void calcularCusto(){
        if (this.getNumeroPaginas() < 50){
            this.setCusto(0.3F * this.getNumeroPaginas());
        } else {
            this.setCusto(0.4F * this.getNumeroPaginas());
        } 
        if (this.getRegiaoOrigem().equals("Europa")){
           this.setCusto(this.getCusto() + 100);
        } 
    }
    
    
    @Override
    public void calcularImposto() {
        this.setImposto(0.2F * this.getCusto());
    }

    public String getRegiaoOrigem() {
        return regiaoOrigem;
    }

    public void setRegiaoOrigem(String regiaoOrigem) {
        this.regiaoOrigem = regiaoOrigem;
    }

}
